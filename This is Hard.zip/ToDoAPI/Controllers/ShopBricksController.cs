﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using LegoLibrary;
using ModelLib.Models;
using System.Diagnostics;
using Microsoft.AspNetCore.Authorization;

namespace ToDoAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class ShopBricksController : ControllerBase
    {
        private readonly LegoShopDBContext _context;

        public ShopBricksController(LegoShopDBContext context)
        {
            _context = context;
        }

        // GET: api/ShopBricks
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ShopBrick>>> GetShopBricks()
        {
            return await _context.ShopBricks.Include(x=>x.Brick).Include(s=> s.Shop).ToListAsync();
        }

        // GET: api/ShopBricks/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ShopBrick>> GetShopBrick(int id)
        {
            var shopBrick = await _context.ShopBricks.FindAsync(id);

            if (shopBrick == null)
            {
                return NotFound();
            }

            return shopBrick;
        }

        // PUT: api/ShopBricks/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{shopId}/{brickId}")]
        public async Task<IActionResult> PutShopBrick(int shopId, int brickId, ShopBrick shopBrick)
        {
            ShopBrick shopBrickNew = _context.ShopBricks.Where(sb=>sb.ShopId == shopId && sb.BrickId == brickId).FirstOrDefault();
            shopBrickNew.BrickId = shopBrick.BrickId;
            shopBrickNew.ShopId = shopBrick.ShopId;
            _context.Entry(shopBrickNew).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (Exception e)
            {
                //Debug.Print(e.ToString());
                return Ok(e.ToString());
            }

            return NoContent();
        }

        // POST: api/ShopBricks
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<ShopBrick>> PostShopBrick(ShopBrick shopBrick)
        {
            _context.ShopBricks.Add(shopBrick);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (ShopBrickExists(shopBrick.BrickId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetShopBrick", new { id = shopBrick.BrickId }, shopBrick);
        }

        // DELETE: api/ShopBricks/5
        [HttpDelete("{shopId}/{brickId}")]
        public async Task<ActionResult<ShopBrick>> DeleteShopBrick(int shopId, int brickId)
        {
            var shopBrick = _context.ShopBricks.Where(sb => sb.ShopId == shopId && sb.BrickId == brickId).FirstOrDefault();
            if (shopBrick == null)
            {
                return NotFound();
            }

            _context.ShopBricks.Remove(shopBrick);
            await _context.SaveChangesAsync();

            return shopBrick;
        }

        private bool ShopBrickExists(int id)
        {
            return _context.ShopBricks.Any(e => e.BrickId == id);
        }
    }
}
