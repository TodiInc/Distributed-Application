﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using LegoLibrary;
using ModelLib.Models;
using Microsoft.AspNetCore.Authorization;

namespace ToDoAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class InventorsController : ControllerBase
    {
        private readonly LegoShopDBContext _context;

        public InventorsController(LegoShopDBContext context)
        {
            _context = context;
        }

        // GET: api/Inventors
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Inventor>>> GetInventors()
        {
            return await _context.Inventors.ToListAsync();
        }

        // GET: api/Inventors/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Inventor>> GetInventor(int id)
        {
            var inventor = await _context.Inventors.FindAsync(id);

            if (inventor == null)
            {
                return NotFound();
            }

            return inventor;
        }

        // PUT: api/Inventors/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutInventor(int id, Inventor inventor)
        {
            if (id != inventor.Id)
            {
                return BadRequest();
            }

            _context.Entry(inventor).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!InventorExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Inventors
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<Inventor>> PostInventor(Inventor inventor)
        {
            _context.Inventors.Add(inventor);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetInventor", new { id = inventor.Id }, inventor);
        }

        // DELETE: api/Inventors/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Inventor>> DeleteInventor(int id)
        {
            var inventor = await _context.Inventors.FindAsync(id);
            if (inventor == null)
            {
                return NotFound();
            }

            _context.Inventors.Remove(inventor);
            await _context.SaveChangesAsync();

            return inventor;
        }

        private bool InventorExists(int id)
        {
            return _context.Inventors.Any(e => e.Id == id);
        }
    }
}
