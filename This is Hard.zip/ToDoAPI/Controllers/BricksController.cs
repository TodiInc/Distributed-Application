﻿using LegoLibrary;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ModelLib.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ToDoAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class BricksController : ControllerBase
    {
        private readonly LegoShopDBContext _context;

        public BricksController(LegoShopDBContext context)
        {
            _context = context;
        }

        // GET: api/Bricks
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Brick>>> GetBricks()
        {
            return await _context.Bricks.ToListAsync();
        }

        // GET: api/Bricks/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Brick>> GetBrick(int id)
        {
            var brick = await _context.Bricks.FindAsync(id);

            if (brick == null)
            {
                return NotFound();
            }

            return brick;
        }

        // PUT: api/Bricks/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutBrick(int id, Brick brick)
        {
            if (id != brick.Id)
            {
                return BadRequest();
            }

            _context.Entry(brick).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BrickExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Bricks
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<Brick>> PostBrick(Brick brick)
        {
            _context.Bricks.Add(brick);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetBrick", new { id = brick.Id }, brick);
        }

        // DELETE: api/Bricks/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Brick>> DeleteBrick(int id)
        {
            var brick = await _context.Bricks.FindAsync(id);
            if (brick == null)
            {
                return NotFound();
            }

            _context.Bricks.Remove(brick);
            await _context.SaveChangesAsync();

            return brick;
        }

        private bool BrickExists(int id)
        {
            return _context.Bricks.Any(e => e.Id == id);
        }
    }
}
