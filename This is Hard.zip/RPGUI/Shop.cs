﻿using Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RPGUI
{
    public partial class ShopForm : Form
    {
        private List<TextBox> allTextBoxes = new List<TextBox>();
        

        public ShopForm()
        {
            InitializeComponent();
            PopulateTable();
            allTextBoxes = Controls.OfType<TextBox>().Cast<Control>().Select(x => x as TextBox).ToList();
        }
        public void PopulateTable()
        {
            DataTable.Rows.Clear();
            var response = LoginForm.client.GetStringAsync("shops").Result;
            var data = JsonConvert.DeserializeObject<IEnumerable<ShopDTO>>(response);

            for (int i = 0; i < data.Count(); i++)
            {
                DataGridViewRow row = (DataGridViewRow)DataTable.Rows[0].Clone();
                row.Cells[0].Value = data.ElementAt(i).ShopName;
                row.Cells[1].Value = data.ElementAt(i).Location;
                row.Cells[2].Value = data.ElementAt(i).Capacity;
                row.Cells[3].Value = data.ElementAt(i).OpenHours.ToString("HH/mm/ss");
                row.Cells[4].Value = data.ElementAt(i).ClosedHours.ToString("HH/mm/ss");
                row.Cells[5].Value = data.ElementAt(i).StaffCount;
                row.Cells[6].Value = data.ElementAt(i).Id;
                DataTable.Rows.Add(row);
            }
        }
        private void ShopForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void B_Add_Click(object sender, EventArgs e)
        {
            foreach (TextBox textBox in allTextBoxes)
            {
                if (textBox.Text.Equals(""))
                {
                    MessageBox.Show("Check your input fields");
                    return;
                }
            }
            ShopDTO content = new ShopDTO() { ShopName = TB_ShopName.Text
                                                ,Location = TB_Location.Text
                                                ,Capacity = long.Parse(TB_Capacity.Text)
                                                ,OpenHours = new DateTime(2356, 12, 12, int.Parse(TB_O_Hours.Text), int.Parse(TB_O_Minutes.Text), int.Parse(TB_O_Seconds.Text))
                                                ,ClosedHours = new DateTime(2356, 12, 12, int.Parse(TB_C_Hours.Text), int.Parse(TB_C_Minutes.Text), int.Parse(TB_C_Seconds.Text))
                                                ,StaffCount = int.Parse(TB_StaffCount.Text)};
            var Jsondata = JsonConvert.SerializeObject(content);
            var response = LoginForm.client.PostAsync("shops", new StringContent(Jsondata.ToString(),Encoding.UTF8,"application/json"));
            
            if (response.Result.StatusCode != System.Net.HttpStatusCode.Created)
                MessageBox.Show("Something's wrong with the inputs");
            PopulateTable();
        }

        private void B_Update_Click(object sender, EventArgs e)
        {
            int selectedRowID = 0;
            foreach (DataGridViewRow item in DataTable.SelectedRows)
            {
                selectedRowID = int.Parse(item.Cells["ID"].Value.ToString());
            }

            foreach (TextBox textBox in allTextBoxes)
            {
                if (textBox.Text.Equals(""))
                {
                    MessageBox.Show("Check your input fields");
                    return;
                }
            }
            ShopDTO content = new ShopDTO()
            {
                ShopName = TB_ShopName.Text
                                                ,
                Location = TB_Location.Text
                                                ,
                Capacity = long.Parse(TB_Capacity.Text)
                                                ,
                OpenHours = new DateTime(2356, 12, 12, int.Parse(TB_O_Hours.Text), int.Parse(TB_O_Minutes.Text), int.Parse(TB_O_Seconds.Text))
                                                ,
                ClosedHours = new DateTime(2356, 12, 12, int.Parse(TB_C_Hours.Text), int.Parse(TB_C_Minutes.Text), int.Parse(TB_C_Seconds.Text))
                                                ,
                StaffCount = int.Parse(TB_StaffCount.Text)
                                                ,
                Id = selectedRowID
            };
            var Jsondata = JsonConvert.SerializeObject(content);
            if(selectedRowID == 0)
            {
                MessageBox.Show("Haven't selected a row");
            }
            var response = LoginForm.client.PutAsync("shops/"+ selectedRowID, new StringContent(Jsondata.ToString(), Encoding.UTF8, "application/json"));
            if (response.Result.StatusCode != System.Net.HttpStatusCode.NoContent)
                MessageBox.Show("Something's wrong with the inputs");
            PopulateTable();
        }

        private void B_Delete_Click(object sender, EventArgs e)
        {
            int selectedRowID = 0;
            foreach (DataGridViewRow item in DataTable.SelectedRows)
            {
                selectedRowID = int.Parse(item.Cells["ID"].Value.ToString());
            }
            if (selectedRowID == 0)
            {
                MessageBox.Show("Haven't selected a row");
                return;
            }
            var response = LoginForm.client.DeleteAsync("shops/"+selectedRowID);
            if (response.Result.StatusCode == System.Net.HttpStatusCode.NoContent)
                MessageBox.Show("No such element");
            PopulateTable();
        }

        private void B_Inventor_Click(object sender, EventArgs e)
        {
            Dispose();
            InventorForm inventorForm = new InventorForm();
            inventorForm.Visible = true;
        }

        private void B_Brick_Click(object sender, EventArgs e)
        {
            Dispose();
            BrickForm brickForm = new BrickForm();
            brickForm.Visible = true;
        }

        private void TB_Capacity_TextChanged(object sender, EventArgs e)
        {
            var textBox = sender as TextBox;
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox.Text, "[^0-9]"))
            {
                MessageBox.Show("Please enter numbers only.");
                textBox.Text = textBox.Text.Remove(textBox.Text.Length - 1);
            }
        }
        private void HoursChanged(object sender, EventArgs e)
        {
            var textBox = sender as TextBox;
            if (textBox.Text.Equals(""))
                return;
            int hours = int.Parse(textBox.Text);
            if (hours < 0 || hours > 24)
            {
                MessageBox.Show("Please enter numbers from 1 to 23 only.");
                textBox.Clear();
                textBox.Focus();
            }
        }
        private void MinutesAndSecondsChanged(object sender, EventArgs e)
        {
            var textBox = sender as TextBox;
            if (textBox.Text.Equals(""))
                return;
            int hours = int.Parse(textBox.Text);
            if (hours < 0 || hours > 60)
            {
                MessageBox.Show("Please enter numbers from 1 to 59 only.");
                textBox.Clear();
                textBox.Focus();
            }
        }

        private void Search_Click(object sender, EventArgs e)
        {
            string searchlocation = TB_Location.Text;
            var response = LoginForm.client.GetStringAsync("shops").Result;
            var data = JsonConvert.DeserializeObject<IEnumerable<ShopDTO>>(response).Where(x => x.Location.Equals(searchlocation));
            if (data == null)
            {
                MessageBox.Show("There is no such location!");
                return;
            }
            DataTable.Rows.Clear();
            for (int i = 0; i < data.Count(); i++)
            {
                DataGridViewRow row = (DataGridViewRow)DataTable.Rows[0].Clone();
                row.Cells[0].Value = data.ElementAt(i).ShopName;
                row.Cells[1].Value = data.ElementAt(i).Location;
                row.Cells[2].Value = data.ElementAt(i).Capacity;
                row.Cells[3].Value = data.ElementAt(i).OpenHours.ToString("HH/mm/ss");
                row.Cells[4].Value = data.ElementAt(i).ClosedHours.ToString("HH/mm/ss");
                row.Cells[5].Value = data.ElementAt(i).StaffCount;
                row.Cells[6].Value = data.ElementAt(i).Id;
                DataTable.Rows.Add(row);
            }
        }

        private void B_ShopsBricks_Click(object sender, EventArgs e)
        {
            Dispose();
            F_ShopBrick shopBrickForm = new F_ShopBrick();
            shopBrickForm.Visible = true;
        }
    }
}
