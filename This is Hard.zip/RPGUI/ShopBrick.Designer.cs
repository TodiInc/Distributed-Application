﻿namespace RPGUI
{
    partial class F_ShopBrick
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Search = new System.Windows.Forms.Button();
            this.B_Inventor = new System.Windows.Forms.Button();
            this.B_Brick = new System.Windows.Forms.Button();
            this.B_Delete = new System.Windows.Forms.Button();
            this.B_Update = new System.Windows.Forms.Button();
            this.B_Add = new System.Windows.Forms.Button();
            this.B_Shop = new System.Windows.Forms.Button();
            this.CB_BrickTypes = new System.Windows.Forms.ComboBox();
            this.CB_ShopLocation = new System.Windows.Forms.ComboBox();
            this.DataTable = new System.Windows.Forms.DataGridView();
            this.Shop_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Brick_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.brickId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shopId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.DataTable)).BeginInit();
            this.SuspendLayout();
            // 
            // Search
            // 
            this.Search.Location = new System.Drawing.Point(12, 294);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(190, 23);
            this.Search.TabIndex = 74;
            this.Search.Text = "Search by Brick Type";
            this.Search.UseVisualStyleBackColor = true;
            this.Search.Click += new System.EventHandler(this.Search_Click);
            // 
            // B_Inventor
            // 
            this.B_Inventor.Location = new System.Drawing.Point(12, 12);
            this.B_Inventor.Name = "B_Inventor";
            this.B_Inventor.Size = new System.Drawing.Size(190, 41);
            this.B_Inventor.TabIndex = 64;
            this.B_Inventor.Text = "Inventor";
            this.B_Inventor.UseVisualStyleBackColor = true;
            this.B_Inventor.Click += new System.EventHandler(this.B_Inventor_Click);
            // 
            // B_Brick
            // 
            this.B_Brick.Location = new System.Drawing.Point(12, 59);
            this.B_Brick.Name = "B_Brick";
            this.B_Brick.Size = new System.Drawing.Size(190, 41);
            this.B_Brick.TabIndex = 63;
            this.B_Brick.Text = "Brick";
            this.B_Brick.UseVisualStyleBackColor = true;
            this.B_Brick.Click += new System.EventHandler(this.B_Brick_Click);
            // 
            // B_Delete
            // 
            this.B_Delete.Location = new System.Drawing.Point(12, 265);
            this.B_Delete.Name = "B_Delete";
            this.B_Delete.Size = new System.Drawing.Size(190, 23);
            this.B_Delete.TabIndex = 51;
            this.B_Delete.Text = "Delete";
            this.B_Delete.UseVisualStyleBackColor = true;
            this.B_Delete.Click += new System.EventHandler(this.B_Delete_Click);
            // 
            // B_Update
            // 
            this.B_Update.Location = new System.Drawing.Point(12, 236);
            this.B_Update.Name = "B_Update";
            this.B_Update.Size = new System.Drawing.Size(190, 23);
            this.B_Update.TabIndex = 50;
            this.B_Update.Text = "Update";
            this.B_Update.UseVisualStyleBackColor = true;
            this.B_Update.Click += new System.EventHandler(this.B_Update_Click);
            // 
            // B_Add
            // 
            this.B_Add.Location = new System.Drawing.Point(12, 207);
            this.B_Add.Name = "B_Add";
            this.B_Add.Size = new System.Drawing.Size(190, 23);
            this.B_Add.TabIndex = 49;
            this.B_Add.Text = "Add";
            this.B_Add.UseVisualStyleBackColor = true;
            this.B_Add.Click += new System.EventHandler(this.B_Add_Click);
            // 
            // B_Shop
            // 
            this.B_Shop.Location = new System.Drawing.Point(12, 106);
            this.B_Shop.Name = "B_Shop";
            this.B_Shop.Size = new System.Drawing.Size(190, 41);
            this.B_Shop.TabIndex = 75;
            this.B_Shop.Text = "Shop";
            this.B_Shop.UseVisualStyleBackColor = true;
            this.B_Shop.Click += new System.EventHandler(this.B_Shop_Click);
            // 
            // CB_BrickTypes
            // 
            this.CB_BrickTypes.FormattingEnabled = true;
            this.CB_BrickTypes.Location = new System.Drawing.Point(12, 153);
            this.CB_BrickTypes.Name = "CB_BrickTypes";
            this.CB_BrickTypes.Size = new System.Drawing.Size(190, 21);
            this.CB_BrickTypes.TabIndex = 76;
            // 
            // CB_ShopLocation
            // 
            this.CB_ShopLocation.FormattingEnabled = true;
            this.CB_ShopLocation.Location = new System.Drawing.Point(12, 180);
            this.CB_ShopLocation.Name = "CB_ShopLocation";
            this.CB_ShopLocation.Size = new System.Drawing.Size(190, 21);
            this.CB_ShopLocation.TabIndex = 77;
            // 
            // DataTable
            // 
            this.DataTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataTable.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Shop_ID,
            this.Brick_ID,
            this.brickId,
            this.shopId});
            this.DataTable.Location = new System.Drawing.Point(208, 12);
            this.DataTable.Name = "DataTable";
            this.DataTable.Size = new System.Drawing.Size(446, 304);
            this.DataTable.TabIndex = 78;
            // 
            // Shop_ID
            // 
            this.Shop_ID.HeaderText = "Shop Location";
            this.Shop_ID.Name = "Shop_ID";
            this.Shop_ID.Width = 300;
            // 
            // Brick_ID
            // 
            this.Brick_ID.HeaderText = "Brick Type";
            this.Brick_ID.Name = "Brick_ID";
            // 
            // brickId
            // 
            this.brickId.HeaderText = "brickId";
            this.brickId.Name = "brickId";
            this.brickId.Visible = false;
            // 
            // shopId
            // 
            this.shopId.HeaderText = "shopId";
            this.shopId.Name = "shopId";
            this.shopId.Visible = false;
            // 
            // F_ShopBrick
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(662, 326);
            this.Controls.Add(this.DataTable);
            this.Controls.Add(this.CB_ShopLocation);
            this.Controls.Add(this.CB_BrickTypes);
            this.Controls.Add(this.B_Shop);
            this.Controls.Add(this.Search);
            this.Controls.Add(this.B_Inventor);
            this.Controls.Add(this.B_Brick);
            this.Controls.Add(this.B_Delete);
            this.Controls.Add(this.B_Update);
            this.Controls.Add(this.B_Add);
            this.Name = "F_ShopBrick";
            this.Text = "At these Shops we have these Bricks";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ShopBrick_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.DataTable)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Search;
        private System.Windows.Forms.Button B_Inventor;
        private System.Windows.Forms.Button B_Brick;
        private System.Windows.Forms.Button B_Delete;
        private System.Windows.Forms.Button B_Update;
        private System.Windows.Forms.Button B_Add;
        private System.Windows.Forms.Button B_Shop;
        private System.Windows.Forms.ComboBox CB_BrickTypes;
        private System.Windows.Forms.ComboBox CB_ShopLocation;
        private System.Windows.Forms.DataGridView DataTable;
        private System.Windows.Forms.DataGridViewTextBoxColumn Shop_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Brick_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn brickId;
        private System.Windows.Forms.DataGridViewTextBoxColumn shopId;
    }
}