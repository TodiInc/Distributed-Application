﻿using Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RPGUI
{
    public partial class BrickForm : Form
    {
        private List<TextBox> allTextBoxes = new List<TextBox>();
        private List<object> Inventors;
        public BrickForm()
        {
            InitializeComponent();
            allTextBoxes = Controls.OfType<TextBox>().Cast<Control>().Select(x => x as TextBox).ToList();
            CB_Inventors.Items.Clear();
            var response = LoginForm.client.GetStringAsync("inventors").Result;
            Inventors = JsonConvert.DeserializeObject<IEnumerable<InventorDTO>>(response).ToList<object>();
            CB_Inventors.Items.AddRange(Inventors.ToArray());

            PopulateTable();
        }
        public void PopulateTable()
        {
            DataTable.Rows.Clear();
            var response = LoginForm.client.GetStringAsync("bricks").Result;
            var data = JsonConvert.DeserializeObject<IEnumerable<BrickDTO>>(response);

            for (int i = 0; i < data.Count(); i++)
            {
                DataGridViewRow row = (DataGridViewRow)DataTable.Rows[0].Clone();
                row.Cells[0].Value = data.ElementAt(i).Type;
                row.Cells[1].Value = data.ElementAt(i).X;
                row.Cells[2].Value = data.ElementAt(i).Y;
                row.Cells[3].Value = data.ElementAt(i).Z;
                row.Cells[4].Value = Inventors.Where(x => (x as InventorDTO).Id == data.ElementAt(i).InventorId).FirstOrDefault().ToString();
                row.Cells[5].Value = data.ElementAt(i).PricePerUnit;
                row.Cells[6].Value = data.ElementAt(i).DateOfCreation.ToString("yyyy/MM/dd");
                row.Cells[7].Value = data.ElementAt(i).Id;
                DataTable.Rows.Add(row);
            }
        }

        private void BrickForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void B_Add_Click(object sender, EventArgs e)
        {
            foreach (TextBox textBox in allTextBoxes)
            {
                if (textBox.Text.Equals(""))
                {
                    MessageBox.Show("Check your input fields");
                    return;
                }
            }
            BrickDTO content = new BrickDTO()
            {
                Type = TB_Type.Text
                                                ,
                X = int.Parse(TB_X.Text)
                                                ,
                Y = int.Parse(TB_Y.Text)
                                                ,
                Z = int.Parse(TB_Z.Text)
                                                ,
                InventorId = (CB_Inventors.SelectedItem as InventorDTO).Id
                                                ,
                PricePerUnit = NUD_Price.Value
                                                ,
                DateOfCreation = DP_DateCreated.Value
            };
            var Jsondata = JsonConvert.SerializeObject(content);
            var response = LoginForm.client.PostAsync("bricks", new StringContent(Jsondata.ToString(), Encoding.UTF8, "application/json"));

            if (response.Result.StatusCode != System.Net.HttpStatusCode.Created)
                MessageBox.Show("Something's wrong with the inputs");
            PopulateTable();
        }

        private void B_Update_Click(object sender, EventArgs e)
        {
            int selectedRowID = 0;
            foreach (DataGridViewRow item in DataTable.SelectedRows)
            {
                selectedRowID = int.Parse(item.Cells["ID"].Value.ToString());
            }
            foreach (TextBox textBox in allTextBoxes)
            {
                if (textBox.Text.Equals(""))
                {
                    MessageBox.Show("Check your input fields");
                    return;
                }
            }

            BrickDTO content = new BrickDTO()
            {
                Type = TB_Type.Text
                                                ,
                X = int.Parse(TB_X.Text)
                                                ,
                Y = int.Parse(TB_Y.Text)
                                                ,
                Z = int.Parse(TB_Z.Text)
                                                ,
                InventorId = (CB_Inventors.SelectedItem as InventorDTO).Id
                                                ,
                PricePerUnit = NUD_Price.Value
                                                ,
                DateOfCreation = DP_DateCreated.Value
                                                ,
                Id = selectedRowID
            };
            var Jsondata = JsonConvert.SerializeObject(content);
            if (selectedRowID == 0)
            {
                MessageBox.Show("Haven't selected a row");
            }
            var response = LoginForm.client.PutAsync("bricks/" + selectedRowID, new StringContent(Jsondata.ToString(), Encoding.UTF8, "application/json"));
            if (response.Result.StatusCode != System.Net.HttpStatusCode.NoContent)
                MessageBox.Show("Something's wrong with the inputs");
            PopulateTable();
        }

        private void B_Delete_Click(object sender, EventArgs e)
        {
            int selectedRowID = 0;
            foreach (DataGridViewRow item in DataTable.SelectedRows)
            {
                selectedRowID = int.Parse(item.Cells["ID"].Value.ToString());
            }
            if (selectedRowID == 0)
            {
                MessageBox.Show("Haven't selected a row");
                return;
            }
            var response = LoginForm.client.DeleteAsync("bricks/" + selectedRowID);
            if (response.Result.StatusCode == System.Net.HttpStatusCode.NoContent)
                MessageBox.Show("No such element");

            PopulateTable();
        }

        private void B_Shop_Click(object sender, EventArgs e)
        {
            Dispose();
            ShopForm shopForm = new ShopForm();
            shopForm.Visible = true;
        }

        private void B_Inventor_Click(object sender, EventArgs e)
        {
            Dispose();
            InventorForm inventorForm = new InventorForm();
            inventorForm.Visible = true;
        }

        private void TB_X_TextChanged(object sender, EventArgs e)
        {
            var textBox = sender as TextBox;
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox.Text, "[^0-9]"))
            {
                MessageBox.Show("Please enter numbers only.");
                textBox.Text = textBox.Text.Remove(textBox.Text.Length - 1);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var textBox = sender as TextBox;
            if (textBox.Text.Equals(""))
                return;
            int hours = int.Parse(textBox.Text);
            if (hours < 0 || hours > 99)
            {
                MessageBox.Show("Please enter numbers from 1 to 99 only.");
                textBox.Clear();
                textBox.Focus();
            }
        }

        private void Search_Click(object sender, EventArgs e)
        {
            string searchType = TB_Type.Text;
            var response = LoginForm.client.GetStringAsync("bricks").Result;
            var data = JsonConvert.DeserializeObject<IEnumerable<BrickDTO>>(response).Where(x => x.Type.Equals(searchType));
            if (data == null)
            {
                MessageBox.Show("There is no such type!");
                return;
            }
            DataTable.Rows.Clear();
            for (int i = 0; i < data.Count(); i++)
            {
                DataGridViewRow row = (DataGridViewRow)DataTable.Rows[0].Clone();
                row.Cells[0].Value = data.ElementAt(i).Type;
                row.Cells[1].Value = data.ElementAt(i).X;
                row.Cells[2].Value = data.ElementAt(i).Y;
                row.Cells[3].Value = data.ElementAt(i).Z;
                row.Cells[4].Value = Inventors.Where(x => (x as InventorDTO).Id == data.ElementAt(i).InventorId).FirstOrDefault().ToString();
                row.Cells[5].Value = data.ElementAt(i).PricePerUnit;
                row.Cells[6].Value = data.ElementAt(i).DateOfCreation.ToString("yyyy/MM/dd");
                row.Cells[7].Value = data.ElementAt(i).Id;
                DataTable.Rows.Add(row);
            }
        }

        private void B_ShopsBricks_Click(object sender, EventArgs e)
        {
            Dispose();
            F_ShopBrick shopBrickForm = new F_ShopBrick();
            shopBrickForm.Visible = true;
        }
    }
}
