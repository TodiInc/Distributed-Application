﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RPGUI
{
    public partial class LoginForm : Form
    {
        public static string token;
        string Username = "Todi";
        string Password = "todipass";
        public static HttpClient client = new HttpClient();
        public BrickForm brickForm;
        public LoginForm()
        {
            InitializeComponent();
            client.BaseAddress = new Uri("http://localhost:53358/api/");
            //client.DefaultRequestHeaders.Add("Authorization","Basic Todi:todipass");
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (TB_Password.Text.Equals(Password) && TB_Username.Text.Equals(Username))
            {
                var response = LoginForm.client.GetStringAsync("login").Result;
                token = response;
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + token);
                brickForm = new BrickForm();
                brickForm.Visible = true;
                Visible = false;
                //Inventors = JsonConvert.DeserializeObject<IEnumerable<InventorDTO>>(response).ToList<object>();
            }
            else
            {
                MessageBox.Show("No such Username or Password!");
                return;
            }
        }
        public void StopProgram()
        {
            Dispose();
        }
    }
}
