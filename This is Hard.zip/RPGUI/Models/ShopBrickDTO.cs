﻿using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    public class ShopBrickDTO
    {
        public int Id { get; set; }
        public ShopDTO Shop { get; set; }
        public int ShopId { get; set; }
        public BrickDTO Brick { get; set; }
        public int BrickId { get; set; }
    }
}
