﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Models
{
    public class InventorDTO
    {
        public int Id { get; set; }

        [StringLength(40, ErrorMessage = "Първото име трябва да бъде между {2} и {1} символа.", MinimumLength = 3)]
        public string FName { get; set; }

        [StringLength(40, ErrorMessage = "Последното име трябва да бъде между {2} и {1} символа.", MinimumLength = 3)]
        public string LName { get; set; }
        public DateTime DateCreated { get; set; }
        public IEnumerable<BrickDTO> Bricks { get; set; }
        public byte AtTheAgeOf { get; set; }
        public DateTime TimeOfCreation { get; set; }
        public override string ToString()
        {
            return FName+" "+LName;
        }
    }
}
