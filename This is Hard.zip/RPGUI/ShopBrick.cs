﻿using Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RPGUI
{
    public partial class F_ShopBrick : Form
    {
        public F_ShopBrick()
        {
            InitializeComponent();
            CB_ShopLocation.Items.Clear();
            CB_BrickTypes.Items.Clear();
            var response = LoginForm.client.GetStringAsync("shops").Result;
            var shopData = JsonConvert.DeserializeObject<IEnumerable<ShopDTO>>(response);
            CB_ShopLocation.Items.AddRange(shopData.ToArray<object>());
            response = LoginForm.client.GetStringAsync("bricks").Result;
            var brickData = JsonConvert.DeserializeObject<IEnumerable<BrickDTO>>(response);
            CB_BrickTypes.Items.AddRange(brickData.ToArray<object>());
            UpdateDataTable();
        }
        public void UpdateDataTable()
        {
            DataTable.Rows.Clear();
            var response = LoginForm.client.GetStringAsync("shopbricks").Result;
            var data = JsonConvert.DeserializeObject<IEnumerable<ShopBrickDTO>>(response);

            for (int i = 0; i < data.Count(); i++)
            {
                response = LoginForm.client.GetStringAsync("bricks/"+data.ElementAt(i).BrickId).Result;
                BrickDTO brick = JsonConvert.DeserializeObject<BrickDTO>(response);
                response = LoginForm.client.GetStringAsync("shops/" + data.ElementAt(i).ShopId).Result;
                ShopDTO shop = JsonConvert.DeserializeObject<ShopDTO>(response);
                DataGridViewRow row = (DataGridViewRow)DataTable.Rows[0].Clone();
                row.Cells[0].Value = shop.Location;
                row.Cells[1].Value = brick.Type;
                row.Cells[2].Value = data.ElementAt(i).BrickId;
                row.Cells[3].Value = data.ElementAt(i).ShopId;
                DataTable.Rows.Add(row);
            }
        }
        private void B_Inventor_Click(object sender, EventArgs e)
        {
            Dispose();
            InventorForm inventorForm = new InventorForm();
            inventorForm.Visible = true;
        }

        private void B_Shop_Click(object sender, EventArgs e)
        {
            Dispose();
            ShopForm shopForm = new ShopForm();
            shopForm.Visible = true;
        }

        private void B_Brick_Click(object sender, EventArgs e)
        {
            Dispose();
            BrickForm brickForm = new BrickForm();
            brickForm.Visible = true;
        }

        private void ShopBrick_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void B_Add_Click(object sender, EventArgs e)
        {
            if (CB_BrickTypes.SelectedItem == null || CB_ShopLocation.SelectedItem == null)
            {
                MessageBox.Show("Haven't selected any items!");
                return;
            }
            ShopBrickDTO content = new ShopBrickDTO()
            {
                BrickId = (CB_BrickTypes.SelectedItem as BrickDTO).Id,
                ShopId = (CB_ShopLocation.SelectedItem as ShopDTO).Id
            };
            var Jsondata = JsonConvert.SerializeObject(content);
            var response = LoginForm.client.PostAsync("shopbricks", new StringContent(Jsondata.ToString(), Encoding.UTF8, "application/json"));

            if (response.Result.StatusCode != System.Net.HttpStatusCode.Created)
                MessageBox.Show("Can't add duplicate items!");
            UpdateDataTable();
        }

        private void B_Update_Click(object sender, EventArgs e)
        {
            int selectedRowShopId = 0;
            int selectedRowBrickId = 0;
            foreach (DataGridViewRow item in DataTable.SelectedRows)
            {
                selectedRowShopId = int.Parse(item.Cells["shopId"].Value.ToString());
                selectedRowBrickId = int.Parse(item.Cells["brickId"].Value.ToString());
            }
            if (selectedRowShopId == 0 && selectedRowBrickId == 0)
            {
                MessageBox.Show("Haven't selected a row");
                return;
            }
            ShopBrickDTO content = new ShopBrickDTO()
            {
                BrickId = (CB_BrickTypes.SelectedItem as BrickDTO).Id,
                ShopId = (CB_ShopLocation.SelectedItem as ShopDTO).Id
            };
            var Jsondata = JsonConvert.SerializeObject(content);
            var response = LoginForm.client.PutAsync("shopbricks/" + selectedRowShopId + "/" + selectedRowBrickId, new StringContent(Jsondata.ToString(), Encoding.UTF8, "application/json"));
            if (response.Result.StatusCode != System.Net.HttpStatusCode.NoContent)
                MessageBox.Show(response.Result.ToString());
            UpdateDataTable();
        }

        private void B_Delete_Click(object sender, EventArgs e)
        {
            int selectedRowShopId = 0;
            int selectedRowBrickId = 0;
            foreach (DataGridViewRow item in DataTable.SelectedRows)
            {
                selectedRowShopId = int.Parse(item.Cells["shopId"].Value.ToString());
                selectedRowBrickId = int.Parse(item.Cells["brickId"].Value.ToString());
            }
            if (selectedRowShopId == 0 && selectedRowBrickId == 0)
            {
                MessageBox.Show("Haven't selected a row");
                return;
            }
            var response = LoginForm.client.DeleteAsync("shopbricks/" + selectedRowShopId + "/" + selectedRowBrickId);
            if (response.Result.StatusCode == System.Net.HttpStatusCode.NoContent)
                MessageBox.Show("No such element");
            UpdateDataTable();
        }

        private void Search_Click(object sender, EventArgs e)
        {
            if (CB_BrickTypes.SelectedItem == null)
            {
                MessageBox.Show("Haven't selected any items!");
                return;
            }
            string searchType = CB_BrickTypes.Text;
            var response = LoginForm.client.GetStringAsync("shopbricks").Result;
            var data = JsonConvert.DeserializeObject<IEnumerable<ShopBrickDTO>>(response).ToList();
            if (data.Count<1)
            {
                MessageBox.Show("There is no such type!");
                return;
            }
            DataTable.Rows.Clear();
            for (int i = 0; i < data.Count(); i++)
            {
                response = LoginForm.client.GetStringAsync("bricks/" + data.ElementAt(i).BrickId).Result;
                BrickDTO brick = JsonConvert.DeserializeObject<BrickDTO>(response);if (brick.Type != searchType) continue;
                response = LoginForm.client.GetStringAsync("shops/" + data.ElementAt(i).ShopId).Result;
                ShopDTO shop = JsonConvert.DeserializeObject<ShopDTO>(response);
                DataGridViewRow row = (DataGridViewRow)DataTable.Rows[0].Clone();
                row.Cells[0].Value = shop.Location;
                row.Cells[1].Value = brick.Type;
                row.Cells[2].Value = data.ElementAt(i).BrickId;
                row.Cells[3].Value = data.ElementAt(i).ShopId;
                DataTable.Rows.Add(row);
            }
        }
    }
}
