﻿namespace RPGUI
{
    partial class ShopForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.B_Inventor = new System.Windows.Forms.Button();
            this.B_Brick = new System.Windows.Forms.Button();
            this.TB_StaffCount = new System.Windows.Forms.TextBox();
            this.TB_O_Hours = new System.Windows.Forms.TextBox();
            this.TB_Capacity = new System.Windows.Forms.TextBox();
            this.TB_Location = new System.Windows.Forms.TextBox();
            this.TB_ShopName = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.B_Delete = new System.Windows.Forms.Button();
            this.B_Update = new System.Windows.Forms.Button();
            this.DataTable = new System.Windows.Forms.DataGridView();
            this.ShopName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Location = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Capacity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OpenHours = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClosedHours = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StaffCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.B_Add = new System.Windows.Forms.Button();
            this.TB_O_Minutes = new System.Windows.Forms.TextBox();
            this.TB_O_Seconds = new System.Windows.Forms.TextBox();
            this.L_Naklonena = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.TB_C_Seconds = new System.Windows.Forms.TextBox();
            this.TB_C_Minutes = new System.Windows.Forms.TextBox();
            this.TB_C_Hours = new System.Windows.Forms.TextBox();
            this.Search = new System.Windows.Forms.Button();
            this.B_ShopsBricks = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DataTable)).BeginInit();
            this.SuspendLayout();
            // 
            // B_Inventor
            // 
            this.B_Inventor.Location = new System.Drawing.Point(14, 12);
            this.B_Inventor.Name = "B_Inventor";
            this.B_Inventor.Size = new System.Drawing.Size(91, 41);
            this.B_Inventor.TabIndex = 35;
            this.B_Inventor.Text = "Inventor";
            this.B_Inventor.UseVisualStyleBackColor = true;
            this.B_Inventor.Click += new System.EventHandler(this.B_Inventor_Click);
            // 
            // B_Brick
            // 
            this.B_Brick.Location = new System.Drawing.Point(110, 12);
            this.B_Brick.Name = "B_Brick";
            this.B_Brick.Size = new System.Drawing.Size(91, 41);
            this.B_Brick.TabIndex = 34;
            this.B_Brick.Text = "Brick";
            this.B_Brick.UseVisualStyleBackColor = true;
            this.B_Brick.Click += new System.EventHandler(this.B_Brick_Click);
            // 
            // TB_StaffCount
            // 
            this.TB_StaffCount.Location = new System.Drawing.Point(104, 239);
            this.TB_StaffCount.Name = "TB_StaffCount";
            this.TB_StaffCount.Size = new System.Drawing.Size(100, 20);
            this.TB_StaffCount.TabIndex = 33;
            this.TB_StaffCount.TextChanged += new System.EventHandler(this.TB_Capacity_TextChanged);
            // 
            // TB_O_Hours
            // 
            this.TB_O_Hours.Location = new System.Drawing.Point(104, 184);
            this.TB_O_Hours.Name = "TB_O_Hours";
            this.TB_O_Hours.Size = new System.Drawing.Size(23, 20);
            this.TB_O_Hours.TabIndex = 31;
            this.TB_O_Hours.TextChanged += new System.EventHandler(this.TB_Capacity_TextChanged);
            this.TB_O_Hours.Leave += new System.EventHandler(this.HoursChanged);
            // 
            // TB_Capacity
            // 
            this.TB_Capacity.Location = new System.Drawing.Point(104, 158);
            this.TB_Capacity.Name = "TB_Capacity";
            this.TB_Capacity.Size = new System.Drawing.Size(100, 20);
            this.TB_Capacity.TabIndex = 30;
            this.TB_Capacity.TextChanged += new System.EventHandler(this.TB_Capacity_TextChanged);
            // 
            // TB_Location
            // 
            this.TB_Location.Location = new System.Drawing.Point(104, 132);
            this.TB_Location.Name = "TB_Location";
            this.TB_Location.Size = new System.Drawing.Size(100, 20);
            this.TB_Location.TabIndex = 29;
            // 
            // TB_ShopName
            // 
            this.TB_ShopName.Location = new System.Drawing.Point(104, 106);
            this.TB_ShopName.Name = "TB_ShopName";
            this.TB_ShopName.Size = new System.Drawing.Size(100, 20);
            this.TB_ShopName.TabIndex = 28;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(11, 242);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 13);
            this.label6.TabIndex = 27;
            this.label6.Text = "Staff Count:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 213);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 13);
            this.label5.TabIndex = 26;
            this.label5.Text = "Closed Hours:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 187);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 13);
            this.label4.TabIndex = 25;
            this.label4.Text = "Open Hours:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 161);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 13);
            this.label3.TabIndex = 24;
            this.label3.Text = "Capacity:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 135);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 13);
            this.label2.TabIndex = 23;
            this.label2.Text = "Location:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 109);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 22;
            this.label1.Text = "ShopName:";
            // 
            // B_Delete
            // 
            this.B_Delete.Location = new System.Drawing.Point(14, 339);
            this.B_Delete.Name = "B_Delete";
            this.B_Delete.Size = new System.Drawing.Size(190, 23);
            this.B_Delete.TabIndex = 21;
            this.B_Delete.Text = "Delete";
            this.B_Delete.UseVisualStyleBackColor = true;
            this.B_Delete.Click += new System.EventHandler(this.B_Delete_Click);
            // 
            // B_Update
            // 
            this.B_Update.Location = new System.Drawing.Point(14, 310);
            this.B_Update.Name = "B_Update";
            this.B_Update.Size = new System.Drawing.Size(190, 23);
            this.B_Update.TabIndex = 20;
            this.B_Update.Text = "Update";
            this.B_Update.UseVisualStyleBackColor = true;
            this.B_Update.Click += new System.EventHandler(this.B_Update_Click);
            // 
            // DataTable
            // 
            this.DataTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataTable.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ShopName,
            this.Location,
            this.Capacity,
            this.OpenHours,
            this.ClosedHours,
            this.StaffCount,
            this.ID});
            this.DataTable.Location = new System.Drawing.Point(210, 12);
            this.DataTable.Name = "DataTable";
            this.DataTable.Size = new System.Drawing.Size(782, 379);
            this.DataTable.TabIndex = 19;
            // 
            // ShopName
            // 
            this.ShopName.HeaderText = "Shop Name";
            this.ShopName.Name = "ShopName";
            // 
            // Location
            // 
            this.Location.HeaderText = "Location";
            this.Location.Name = "Location";
            this.Location.Width = 200;
            // 
            // Capacity
            // 
            this.Capacity.HeaderText = "Capacity";
            this.Capacity.Name = "Capacity";
            this.Capacity.Width = 50;
            // 
            // OpenHours
            // 
            this.OpenHours.HeaderText = "Open Hours";
            this.OpenHours.Name = "OpenHours";
            this.OpenHours.Width = 150;
            // 
            // ClosedHours
            // 
            this.ClosedHours.HeaderText = "Closed Hours";
            this.ClosedHours.Name = "ClosedHours";
            this.ClosedHours.Width = 150;
            // 
            // StaffCount
            // 
            this.StaffCount.HeaderText = "Staff Count";
            this.StaffCount.Name = "StaffCount";
            this.StaffCount.Width = 85;
            // 
            // ID
            // 
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.Visible = false;
            // 
            // B_Add
            // 
            this.B_Add.Location = new System.Drawing.Point(14, 281);
            this.B_Add.Name = "B_Add";
            this.B_Add.Size = new System.Drawing.Size(190, 23);
            this.B_Add.TabIndex = 18;
            this.B_Add.Text = "Add";
            this.B_Add.UseVisualStyleBackColor = true;
            this.B_Add.Click += new System.EventHandler(this.B_Add_Click);
            // 
            // TB_O_Minutes
            // 
            this.TB_O_Minutes.Location = new System.Drawing.Point(142, 184);
            this.TB_O_Minutes.Name = "TB_O_Minutes";
            this.TB_O_Minutes.Size = new System.Drawing.Size(23, 20);
            this.TB_O_Minutes.TabIndex = 36;
            this.TB_O_Minutes.TextChanged += new System.EventHandler(this.TB_Capacity_TextChanged);
            this.TB_O_Minutes.Leave += new System.EventHandler(this.MinutesAndSecondsChanged);
            // 
            // TB_O_Seconds
            // 
            this.TB_O_Seconds.Location = new System.Drawing.Point(181, 184);
            this.TB_O_Seconds.Name = "TB_O_Seconds";
            this.TB_O_Seconds.Size = new System.Drawing.Size(23, 20);
            this.TB_O_Seconds.TabIndex = 37;
            this.TB_O_Seconds.TextChanged += new System.EventHandler(this.TB_Capacity_TextChanged);
            this.TB_O_Seconds.Leave += new System.EventHandler(this.MinutesAndSecondsChanged);
            // 
            // L_Naklonena
            // 
            this.L_Naklonena.AutoSize = true;
            this.L_Naklonena.Location = new System.Drawing.Point(130, 187);
            this.L_Naklonena.Name = "L_Naklonena";
            this.L_Naklonena.Size = new System.Drawing.Size(10, 13);
            this.L_Naklonena.TabIndex = 38;
            this.L_Naklonena.Text = ":";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(170, 187);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(10, 13);
            this.label7.TabIndex = 39;
            this.label7.Text = ":";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(170, 216);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(10, 13);
            this.label8.TabIndex = 44;
            this.label8.Text = ":";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(130, 216);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(10, 13);
            this.label9.TabIndex = 43;
            this.label9.Text = ":";
            // 
            // TB_C_Seconds
            // 
            this.TB_C_Seconds.Location = new System.Drawing.Point(181, 213);
            this.TB_C_Seconds.Name = "TB_C_Seconds";
            this.TB_C_Seconds.Size = new System.Drawing.Size(23, 20);
            this.TB_C_Seconds.TabIndex = 42;
            this.TB_C_Seconds.TextChanged += new System.EventHandler(this.TB_Capacity_TextChanged);
            this.TB_C_Seconds.Leave += new System.EventHandler(this.MinutesAndSecondsChanged);
            // 
            // TB_C_Minutes
            // 
            this.TB_C_Minutes.Location = new System.Drawing.Point(142, 213);
            this.TB_C_Minutes.Name = "TB_C_Minutes";
            this.TB_C_Minutes.Size = new System.Drawing.Size(23, 20);
            this.TB_C_Minutes.TabIndex = 41;
            this.TB_C_Minutes.TextChanged += new System.EventHandler(this.TB_Capacity_TextChanged);
            this.TB_C_Minutes.Leave += new System.EventHandler(this.MinutesAndSecondsChanged);
            // 
            // TB_C_Hours
            // 
            this.TB_C_Hours.Location = new System.Drawing.Point(104, 213);
            this.TB_C_Hours.Name = "TB_C_Hours";
            this.TB_C_Hours.Size = new System.Drawing.Size(23, 20);
            this.TB_C_Hours.TabIndex = 40;
            this.TB_C_Hours.TextChanged += new System.EventHandler(this.TB_Capacity_TextChanged);
            this.TB_C_Hours.Leave += new System.EventHandler(this.HoursChanged);
            // 
            // Search
            // 
            this.Search.Location = new System.Drawing.Point(14, 368);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(190, 23);
            this.Search.TabIndex = 48;
            this.Search.Text = "Search by location";
            this.Search.UseVisualStyleBackColor = true;
            this.Search.Click += new System.EventHandler(this.Search_Click);
            // 
            // B_ShopsBricks
            // 
            this.B_ShopsBricks.Location = new System.Drawing.Point(14, 59);
            this.B_ShopsBricks.Name = "B_ShopsBricks";
            this.B_ShopsBricks.Size = new System.Drawing.Size(187, 41);
            this.B_ShopsBricks.TabIndex = 51;
            this.B_ShopsBricks.Text = "Shops and Bricks";
            this.B_ShopsBricks.UseVisualStyleBackColor = true;
            this.B_ShopsBricks.Click += new System.EventHandler(this.B_ShopsBricks_Click);
            // 
            // ShopForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1002, 403);
            this.Controls.Add(this.B_ShopsBricks);
            this.Controls.Add(this.Search);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.TB_C_Seconds);
            this.Controls.Add(this.TB_C_Minutes);
            this.Controls.Add(this.TB_C_Hours);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.L_Naklonena);
            this.Controls.Add(this.TB_O_Seconds);
            this.Controls.Add(this.TB_O_Minutes);
            this.Controls.Add(this.B_Inventor);
            this.Controls.Add(this.B_Brick);
            this.Controls.Add(this.TB_StaffCount);
            this.Controls.Add(this.TB_O_Hours);
            this.Controls.Add(this.TB_Capacity);
            this.Controls.Add(this.TB_Location);
            this.Controls.Add(this.TB_ShopName);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.B_Delete);
            this.Controls.Add(this.B_Update);
            this.Controls.Add(this.DataTable);
            this.Controls.Add(this.B_Add);
            this.Name = "ShopForm";
            this.Text = "Shop";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ShopForm_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.DataTable)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button B_Inventor;
        private System.Windows.Forms.Button B_Brick;
        private System.Windows.Forms.TextBox TB_StaffCount;
        private System.Windows.Forms.TextBox TB_O_Hours;
        private System.Windows.Forms.TextBox TB_Capacity;
        private System.Windows.Forms.TextBox TB_Location;
        private System.Windows.Forms.TextBox TB_ShopName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button B_Delete;
        private System.Windows.Forms.Button B_Update;
        private System.Windows.Forms.DataGridView DataTable;
        private System.Windows.Forms.DataGridViewTextBoxColumn ShopName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Location;
        private System.Windows.Forms.DataGridViewTextBoxColumn Capacity;
        private System.Windows.Forms.DataGridViewTextBoxColumn OpenHours;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClosedHours;
        private System.Windows.Forms.DataGridViewTextBoxColumn StaffCount;
        private System.Windows.Forms.Button B_Add;
        private System.Windows.Forms.TextBox TB_O_Minutes;
        private System.Windows.Forms.TextBox TB_O_Seconds;
        private System.Windows.Forms.Label L_Naklonena;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox TB_C_Seconds;
        private System.Windows.Forms.TextBox TB_C_Minutes;
        private System.Windows.Forms.TextBox TB_C_Hours;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.Button Search;
        private System.Windows.Forms.Button B_ShopsBricks;
    }
}