﻿using Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RPGUI
{
    public partial class InventorForm : Form
    {
        private List<TextBox> allTextBoxes = new List<TextBox>();
        public InventorForm()
        {
            InitializeComponent();
            UpdateDataTable();
            allTextBoxes = Controls.OfType<TextBox>().Cast<Control>().Select(x => x as TextBox).ToList();
        }
        public void UpdateDataTable( )
        {

            DataTable.Rows.Clear();
            var response = LoginForm.client.GetStringAsync("inventors").Result;
                    var data = JsonConvert.DeserializeObject<IEnumerable<InventorDTO>>(response);

            for (int i = 0; i < data.Count(); i++)
            {
                DataGridViewRow row = (DataGridViewRow)DataTable.Rows[0].Clone();
                row.Cells[0].Value = data.ElementAt(i).FName;
                row.Cells[1].Value = data.ElementAt(i).LName;
                row.Cells[2].Value = data.ElementAt(i).DateCreated.ToString("yyyy/MM/dd");
                row.Cells[3].Value = data.ElementAt(i).AtTheAgeOf;
                row.Cells[4].Value = data.ElementAt(i).TimeOfCreation.ToString("HH/mm/ss");
                row.Cells[5].Value = data.ElementAt(i).Id;
                DataTable.Rows.Add(row);
            }
        }

        private void InventorForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void B_Add_Click(object sender, EventArgs e)
        {
            foreach (TextBox textBox in allTextBoxes)
            {
                if (textBox.Text.Equals(""))
                {
                    MessageBox.Show("Check your input fields");
                    return;
                }
            }
            InventorDTO content = new InventorDTO()
            {
                FName = TB_FirstName.Text,
                LName = TB_LastName.Text,
                DateCreated = DP_DateCreated.Value,
                AtTheAgeOf = (byte)NUD_Age.Value,
                TimeOfCreation = new DateTime(2356, 12, 12, int.Parse(TB_Hours.Text), int.Parse(TB_Minutes.Text), int.Parse(TB_Seconds.Text))
            };
            var Jsondata = JsonConvert.SerializeObject(content);
            var response = LoginForm.client.PostAsync("inventors", new StringContent(Jsondata.ToString(), Encoding.UTF8, "application/json"));

            if (response.Result.StatusCode != System.Net.HttpStatusCode.Created)
                MessageBox.Show("Something's wrong with the inputs");
            UpdateDataTable();
        }

        private void B_Update_Click(object sender, EventArgs e)
        {
            int selectedRowID = 0;
            foreach (DataGridViewRow item in DataTable.SelectedRows)
            {
                selectedRowID = int.Parse(item.Cells["ID"].Value.ToString());
            }
            foreach (TextBox textBox in allTextBoxes)
            {
                if (textBox.Text.Equals(""))
                {
                    MessageBox.Show("Check your input fields");
                    return;
                }
            }
            InventorDTO content = new InventorDTO()
            {
                FName = TB_FirstName.Text,
                LName = TB_LastName.Text,
                DateCreated = DP_DateCreated.Value,
                AtTheAgeOf = (byte)NUD_Age.Value,
                TimeOfCreation = new DateTime(2356, 12, 12, int.Parse(TB_Hours.Text), int.Parse(TB_Minutes.Text), int.Parse(TB_Seconds.Text)),
                Id = selectedRowID
            };
            var Jsondata = JsonConvert.SerializeObject(content);
            if (selectedRowID == 0)
            {
                MessageBox.Show("Haven't selected a row");
            }
            var response = LoginForm.client.PutAsync("inventors/" + selectedRowID, new StringContent(Jsondata.ToString(), Encoding.UTF8, "application/json"));
            if (response.Result.StatusCode != System.Net.HttpStatusCode.NoContent)
                MessageBox.Show("Something's wrong with the inputs");
            UpdateDataTable();
        }

        private void B_Delete_Click(object sender, EventArgs e)
        {
            int selectedRowID = 0;
            foreach (DataGridViewRow item in DataTable.SelectedRows)
            {
                selectedRowID = int.Parse(item.Cells["ID"].Value.ToString());
            }
            if (selectedRowID == 0)
            {
                MessageBox.Show("Haven't selected a row");
                return;
            }
            var response = LoginForm.client.DeleteAsync("inventors/" + selectedRowID);
            if (response.Result.StatusCode == System.Net.HttpStatusCode.NoContent)
                MessageBox.Show("No such element");
            UpdateDataTable();
        }

        private void B_Shop_Click(object sender, EventArgs e)
        {
            Dispose();
            ShopForm shopForm = new ShopForm();
            shopForm.Visible = true;
        }

        private void B_Brick_Click(object sender, EventArgs e)
        {
            Dispose();
            BrickForm brickForm = new BrickForm();
            brickForm.Visible = true;
        }
        private void TB_Capacity_TextChanged(object sender, EventArgs e)
        {
            var textBox = sender as TextBox;
            if (System.Text.RegularExpressions.Regex.IsMatch(textBox.Text, "[^0-9]"))
            {
                MessageBox.Show("Please enter numbers only.");
                textBox.Text = textBox.Text.Remove(textBox.Text.Length - 1);
            }
        }
        private void HoursChanged(object sender, EventArgs e)
        {
            var textBox = sender as TextBox;
            if (textBox.Text.Equals(""))
                return;
            int hours = int.Parse(textBox.Text);
            if (hours < 0 || hours > 24)
            {
                MessageBox.Show("Please enter numbers from 1 to 23 only.");
                textBox.Clear();
                textBox.Focus();
            }
        }
        private void MinutesAndSecondsChanged(object sender, EventArgs e)
        {
            var textBox = sender as TextBox;
            if (textBox.Text.Equals(""))
                return;
            int hours = int.Parse(textBox.Text);
            if (hours < 0 || hours > 60)
            {
                MessageBox.Show("Please enter numbers from 1 to 59 only.");
                textBox.Clear();
                textBox.Focus();
            }
        }

        private void Search_Click(object sender, EventArgs e)
        {
            string searchName = TB_FirstName.Text;
            var response = LoginForm.client.GetStringAsync("inventors").Result;
            var data = JsonConvert.DeserializeObject<IEnumerable<InventorDTO>>(response).Where(x=> x.FName.Equals(searchName));
            if(data == null)
            {
                MessageBox.Show("There is no such name!");
                return;
            }
            DataTable.Rows.Clear();
            for (int i = 0; i < data.Count(); i++)
            {
                DataGridViewRow row = (DataGridViewRow)DataTable.Rows[0].Clone();
                row.Cells[0].Value = data.ElementAt(i).FName;
                row.Cells[1].Value = data.ElementAt(i).LName;
                row.Cells[2].Value = data.ElementAt(i).DateCreated.ToString("yyyy/MM/dd");
                row.Cells[3].Value = data.ElementAt(i).AtTheAgeOf;
                row.Cells[4].Value = data.ElementAt(i).TimeOfCreation.ToString("HH/mm/ss");
                row.Cells[5].Value = data.ElementAt(i).Id;
                DataTable.Rows.Add(row);
            }
        }

        private void B_ShopsBricks_Click(object sender, EventArgs e)
        {
            Dispose();
            F_ShopBrick shopBrickForm = new F_ShopBrick();
            shopBrickForm.Visible = true;
        }
    }
}
