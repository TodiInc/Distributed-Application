﻿namespace RPGUI
{
    partial class InventorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.B_Add = new System.Windows.Forms.Button();
            this.DataTable = new System.Windows.Forms.DataGridView();
            this.FName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DateCreated = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AtAge = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TimeCreated = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.B_Update = new System.Windows.Forms.Button();
            this.B_Delete = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.TB_FirstName = new System.Windows.Forms.TextBox();
            this.TB_LastName = new System.Windows.Forms.TextBox();
            this.B_Brick = new System.Windows.Forms.Button();
            this.B_Shop = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.L_Naklonena = new System.Windows.Forms.Label();
            this.TB_Seconds = new System.Windows.Forms.TextBox();
            this.TB_Minutes = new System.Windows.Forms.TextBox();
            this.TB_Hours = new System.Windows.Forms.TextBox();
            this.NUD_Age = new System.Windows.Forms.NumericUpDown();
            this.DP_DateCreated = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.Search = new System.Windows.Forms.Button();
            this.B_ShopsBricks = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DataTable)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD_Age)).BeginInit();
            this.SuspendLayout();
            // 
            // B_Add
            // 
            this.B_Add.Location = new System.Drawing.Point(12, 281);
            this.B_Add.Name = "B_Add";
            this.B_Add.Size = new System.Drawing.Size(190, 23);
            this.B_Add.TabIndex = 0;
            this.B_Add.Text = "Add";
            this.B_Add.UseVisualStyleBackColor = true;
            this.B_Add.Click += new System.EventHandler(this.B_Add_Click);
            // 
            // DataTable
            // 
            this.DataTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataTable.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.FName,
            this.LName,
            this.DateCreated,
            this.AtAge,
            this.TimeCreated,
            this.ID});
            this.DataTable.Location = new System.Drawing.Point(208, 12);
            this.DataTable.Name = "DataTable";
            this.DataTable.Size = new System.Drawing.Size(749, 379);
            this.DataTable.TabIndex = 1;
            // 
            // FName
            // 
            this.FName.HeaderText = "First Name";
            this.FName.Name = "FName";
            // 
            // LName
            // 
            this.LName.HeaderText = "Last Name";
            this.LName.Name = "LName";
            // 
            // DateCreated
            // 
            this.DateCreated.HeaderText = "Date first brick created";
            this.DateCreated.Name = "DateCreated";
            this.DateCreated.Width = 200;
            // 
            // AtAge
            // 
            this.AtAge.HeaderText = "At the Age of";
            this.AtAge.Name = "AtAge";
            // 
            // TimeCreated
            // 
            this.TimeCreated.HeaderText = "Time of Creation";
            this.TimeCreated.Name = "TimeCreated";
            this.TimeCreated.Width = 200;
            // 
            // ID
            // 
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.Visible = false;
            // 
            // B_Update
            // 
            this.B_Update.Location = new System.Drawing.Point(12, 310);
            this.B_Update.Name = "B_Update";
            this.B_Update.Size = new System.Drawing.Size(190, 23);
            this.B_Update.TabIndex = 2;
            this.B_Update.Text = "Update";
            this.B_Update.UseVisualStyleBackColor = true;
            this.B_Update.Click += new System.EventHandler(this.B_Update_Click);
            // 
            // B_Delete
            // 
            this.B_Delete.Location = new System.Drawing.Point(12, 339);
            this.B_Delete.Name = "B_Delete";
            this.B_Delete.Size = new System.Drawing.Size(190, 23);
            this.B_Delete.TabIndex = 3;
            this.B_Delete.Text = "Delete";
            this.B_Delete.UseVisualStyleBackColor = true;
            this.B_Delete.Click += new System.EventHandler(this.B_Delete_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 130);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "First Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 156);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Last Name:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 181);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "At the Age of:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 210);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "Time of Creation:";
            // 
            // TB_FirstName
            // 
            this.TB_FirstName.Location = new System.Drawing.Point(102, 127);
            this.TB_FirstName.Name = "TB_FirstName";
            this.TB_FirstName.Size = new System.Drawing.Size(100, 20);
            this.TB_FirstName.TabIndex = 10;
            // 
            // TB_LastName
            // 
            this.TB_LastName.Location = new System.Drawing.Point(102, 153);
            this.TB_LastName.Name = "TB_LastName";
            this.TB_LastName.Size = new System.Drawing.Size(100, 20);
            this.TB_LastName.TabIndex = 11;
            // 
            // B_Brick
            // 
            this.B_Brick.Location = new System.Drawing.Point(108, 12);
            this.B_Brick.Name = "B_Brick";
            this.B_Brick.Size = new System.Drawing.Size(91, 41);
            this.B_Brick.TabIndex = 16;
            this.B_Brick.Text = "Brick";
            this.B_Brick.UseVisualStyleBackColor = true;
            this.B_Brick.Click += new System.EventHandler(this.B_Brick_Click);
            // 
            // B_Shop
            // 
            this.B_Shop.Location = new System.Drawing.Point(12, 12);
            this.B_Shop.Name = "B_Shop";
            this.B_Shop.Size = new System.Drawing.Size(91, 41);
            this.B_Shop.TabIndex = 17;
            this.B_Shop.Text = "Shop";
            this.B_Shop.UseVisualStyleBackColor = true;
            this.B_Shop.Click += new System.EventHandler(this.B_Shop_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(168, 210);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(10, 13);
            this.label7.TabIndex = 44;
            this.label7.Text = ":";
            // 
            // L_Naklonena
            // 
            this.L_Naklonena.AutoSize = true;
            this.L_Naklonena.Location = new System.Drawing.Point(128, 210);
            this.L_Naklonena.Name = "L_Naklonena";
            this.L_Naklonena.Size = new System.Drawing.Size(10, 13);
            this.L_Naklonena.TabIndex = 43;
            this.L_Naklonena.Text = ":";
            // 
            // TB_Seconds
            // 
            this.TB_Seconds.Location = new System.Drawing.Point(179, 207);
            this.TB_Seconds.Name = "TB_Seconds";
            this.TB_Seconds.Size = new System.Drawing.Size(23, 20);
            this.TB_Seconds.TabIndex = 42;
            this.TB_Seconds.TextChanged += new System.EventHandler(this.TB_Capacity_TextChanged);
            this.TB_Seconds.Leave += new System.EventHandler(this.MinutesAndSecondsChanged);
            // 
            // TB_Minutes
            // 
            this.TB_Minutes.Location = new System.Drawing.Point(140, 207);
            this.TB_Minutes.Name = "TB_Minutes";
            this.TB_Minutes.Size = new System.Drawing.Size(23, 20);
            this.TB_Minutes.TabIndex = 41;
            this.TB_Minutes.TextChanged += new System.EventHandler(this.TB_Capacity_TextChanged);
            this.TB_Minutes.Leave += new System.EventHandler(this.MinutesAndSecondsChanged);
            // 
            // TB_Hours
            // 
            this.TB_Hours.Location = new System.Drawing.Point(102, 207);
            this.TB_Hours.Name = "TB_Hours";
            this.TB_Hours.Size = new System.Drawing.Size(23, 20);
            this.TB_Hours.TabIndex = 40;
            this.TB_Hours.TextChanged += new System.EventHandler(this.TB_Capacity_TextChanged);
            this.TB_Hours.Leave += new System.EventHandler(this.HoursChanged);
            // 
            // NUD_Age
            // 
            this.NUD_Age.Location = new System.Drawing.Point(102, 179);
            this.NUD_Age.Name = "NUD_Age";
            this.NUD_Age.Size = new System.Drawing.Size(100, 20);
            this.NUD_Age.TabIndex = 46;
            // 
            // DP_DateCreated
            // 
            this.DP_DateCreated.Location = new System.Drawing.Point(47, 255);
            this.DP_DateCreated.Name = "DP_DateCreated";
            this.DP_DateCreated.Size = new System.Drawing.Size(131, 20);
            this.DP_DateCreated.TabIndex = 45;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(56, 239);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Date First Brick Created:";
            // 
            // Search
            // 
            this.Search.Location = new System.Drawing.Point(12, 368);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(190, 23);
            this.Search.TabIndex = 47;
            this.Search.Text = "Search by First Name";
            this.Search.UseVisualStyleBackColor = true;
            this.Search.Click += new System.EventHandler(this.Search_Click);
            // 
            // B_ShopsBricks
            // 
            this.B_ShopsBricks.Location = new System.Drawing.Point(12, 59);
            this.B_ShopsBricks.Name = "B_ShopsBricks";
            this.B_ShopsBricks.Size = new System.Drawing.Size(187, 41);
            this.B_ShopsBricks.TabIndex = 50;
            this.B_ShopsBricks.Text = "Shops and Bricks";
            this.B_ShopsBricks.UseVisualStyleBackColor = true;
            this.B_ShopsBricks.Click += new System.EventHandler(this.B_ShopsBricks_Click);
            // 
            // InventorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(970, 403);
            this.Controls.Add(this.B_ShopsBricks);
            this.Controls.Add(this.Search);
            this.Controls.Add(this.NUD_Age);
            this.Controls.Add(this.DP_DateCreated);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.L_Naklonena);
            this.Controls.Add(this.TB_Seconds);
            this.Controls.Add(this.TB_Minutes);
            this.Controls.Add(this.TB_Hours);
            this.Controls.Add(this.B_Shop);
            this.Controls.Add(this.B_Brick);
            this.Controls.Add(this.TB_LastName);
            this.Controls.Add(this.TB_FirstName);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.B_Delete);
            this.Controls.Add(this.B_Update);
            this.Controls.Add(this.DataTable);
            this.Controls.Add(this.B_Add);
            this.Name = "InventorForm";
            this.Text = "Inventor";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.InventorForm_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.DataTable)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NUD_Age)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button B_Add;
        private System.Windows.Forms.DataGridView DataTable;
        private System.Windows.Forms.Button B_Update;
        private System.Windows.Forms.Button B_Delete;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TB_FirstName;
        private System.Windows.Forms.TextBox TB_LastName;
        private System.Windows.Forms.Button B_Brick;
        private System.Windows.Forms.Button B_Shop;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label L_Naklonena;
        private System.Windows.Forms.TextBox TB_Seconds;
        private System.Windows.Forms.TextBox TB_Minutes;
        private System.Windows.Forms.TextBox TB_Hours;
        private System.Windows.Forms.NumericUpDown NUD_Age;
        private System.Windows.Forms.DataGridViewTextBoxColumn FName;
        private System.Windows.Forms.DataGridViewTextBoxColumn LName;
        private System.Windows.Forms.DataGridViewTextBoxColumn DateCreated;
        private System.Windows.Forms.DataGridViewTextBoxColumn AtAge;
        private System.Windows.Forms.DataGridViewTextBoxColumn TimeCreated;
        private System.Windows.Forms.DateTimePicker DP_DateCreated;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.Button Search;
        private System.Windows.Forms.Button B_ShopsBricks;
    }
}