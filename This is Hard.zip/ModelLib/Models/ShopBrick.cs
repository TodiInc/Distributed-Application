﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ModelLib.Models
{
    public class ShopBrick
    {
        public int Id { get; set; }
        public Shop Shop { get; set; }
        public int ShopId { get; set; }
        public Brick Brick { get; set; }
        public int BrickId { get; set; }
    }
}
