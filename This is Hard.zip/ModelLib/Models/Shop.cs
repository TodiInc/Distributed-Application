﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ModelLib.Models
{
    public class Shop
    {
        public int Id { get; set; }
        [StringLength(20, ErrorMessage = "Името трябва да бъде между {2} и {1} символа.", MinimumLength = 3)]
        public string ShopName { get; set; }
        [StringLength(40, ErrorMessage = "Локацията трябва да бъде между {2} и {1} символа.", MinimumLength = 3)]
        public string Location { get; set; }
        public long Capacity { get; set; }
        public List<ShopBrick> ShopBricks { get; set; }
        public ICollection<Brick> Bricks { get; set; }
        public DateTime OpenHours { get; set; }
        public DateTime ClosedHours { get; set; }
        public int StaffCount { get; set; }
    }
}
