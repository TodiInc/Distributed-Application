﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ModelLib.Models
{
    public class Brick
    {
        public int Id { get; set; }
        [StringLength(40, ErrorMessage = "Типът трябва да бъде между {2} и {1} символа.", MinimumLength = 3)]
        public string Type { get; set; }
        public int X { get; set; }
        public int Y { get; set; }
        public int Z { get; set; }
        public List<ShopBrick> ShopBricks { get; set; }
        public Inventor Inventor { get; set; }
        public int InventorId { get; set; }

        [Column(TypeName = "decimal(4,2)")]
        public decimal PricePerUnit { get; set; }
        public DateTime DateOfCreation { get; set; }

    }
}
