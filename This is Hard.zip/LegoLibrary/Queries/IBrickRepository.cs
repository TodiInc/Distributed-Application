﻿using System;
using System.Collections.Generic;
using System.Text;
using ModelLib.Models;

namespace LegoLibrary.Queries
{
    public interface IBrickRepository
    {
        IEnumerable<Brick> GetBricks();
        Brick GetBrickByID(int brickId);
        void InsertBrick(Brick brick);
        void DeleteBrick(int brickId);
        void UpdateBrick(Brick brick);
        void Save();
    }
}
