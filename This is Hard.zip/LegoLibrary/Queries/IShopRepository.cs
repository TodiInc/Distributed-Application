﻿using System;
using System.Collections.Generic;
using System.Text;
using ModelLib.Models;

namespace LegoLibrary.Queries
{
    public interface IShopRepository
    {
        IEnumerable<Shop> GetShops();
        Shop GetShopByID(int shopId);
        void InsertShop(Shop shop);
        void DeleteShop(int shopId);
        void UpdateShop(Shop shop);
        void Save();
    }
}
