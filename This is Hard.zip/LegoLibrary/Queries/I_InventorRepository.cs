﻿using System;
using System.Collections.Generic;
using System.Text;
using ModelLib.Models;

namespace LegoLibrary.Queries
{
    interface I_InventorRepository
    {
        IEnumerable<Inventor> GetInventors();
        Inventor GetInventorByID(int inventorId);
        void InsertInventor(Inventor inventor);
        void DeleteInventor(int inventorId);
        void UpdateInventor(Inventor inventor);
        void Save();
    }
}
