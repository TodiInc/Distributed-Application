﻿using Microsoft.EntityFrameworkCore;
using ModelLib.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Text;

namespace LegoLibrary
{
    public class LegoShopDBContext : DbContext
    {
        public LegoShopDBContext(DbContextOptions<LegoShopDBContext> options)
            : base(options)
        {

        }
        public DbSet<Brick> Bricks { get; set; }
        public DbSet<Shop> Shops { get; set; }
        public DbSet<Inventor> Inventors { get; set; }
        public DbSet<ShopBrick> ShopBricks { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder
                .UseSqlServer("Server = DESKTOP-F1L6PLQ\\SQLEXPRESS; Database = LegoHistoryDB; User Id = Todi; Password = todipass;");

            base.OnConfiguring(optionsBuilder);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Brick>()
                .HasOne(b => b.Inventor)
                .WithMany(i => i.Bricks)
                .HasForeignKey(b=>b.InventorId).OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<ShopBrick>()
                .HasKey(sb => sb.Id);

            modelBuilder.Entity<ShopBrick>()
                .HasOne(sb => sb.Brick)
                .WithMany(b => b.ShopBricks)
                .HasForeignKey(sb => sb.BrickId);

            modelBuilder.Entity<ShopBrick>()
                .HasOne(sb => sb.Shop)
                .WithMany(s => s.ShopBricks)
                .HasForeignKey(sb => sb.ShopId);

            modelBuilder.Entity<Brick>()
                .HasIndex(u => u.Type)
                .IsUnique();

            modelBuilder.Entity<Shop>()
                .HasIndex(u => u.Location)
                .IsUnique();

            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Brick>().HasData(
                new Brick { Id = 1, Type = "Brick", X = 3, Y = 2, Z = 3, InventorId = 1, PricePerUnit = 00.02m, DateOfCreation = new DateTime(1522, 12, 10) }
                );
            modelBuilder.Entity<Inventor>().HasData(
                new Inventor { Id = 1, FName = "Todi", LName = "Boqnov", DateCreated = new DateTime(1522, 12, 10), AtTheAgeOf = 15, TimeOfCreation = new DateTime(2356, 12, 12, 21, 12, 52) }
                );
            modelBuilder.Entity<Shop>().HasData(
                new Shop { Id = 1, ShopName = "LegoLand", Location = "No:3 Kocatepe, Istanbul", Capacity = 526325215, OpenHours = new DateTime(2356, 12, 12, 08, 00, 00), ClosedHours = new DateTime(2356, 12, 12, 19, 00, 00), StaffCount = 500 }
                );
            modelBuilder.Entity<ShopBrick>().HasData(
                new ShopBrick {Id = 1, BrickId = 1, ShopId = 1 }
                );
        }
    }
}
