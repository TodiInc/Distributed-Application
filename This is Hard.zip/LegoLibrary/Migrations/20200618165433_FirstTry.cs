﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace LegoLibrary.Migrations
{
    public partial class FirstTry : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Inventors",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FName = table.Column<string>(maxLength: 40, nullable: true),
                    LName = table.Column<string>(maxLength: 40, nullable: true),
                    DateCreated = table.Column<DateTime>(nullable: false),
                    AtTheAgeOf = table.Column<byte>(nullable: false),
                    TimeOfCreation = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Inventors", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Shops",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ShopName = table.Column<string>(maxLength: 20, nullable: true),
                    Location = table.Column<string>(maxLength: 40, nullable: true),
                    Capacity = table.Column<long>(nullable: false),
                    OpenHours = table.Column<DateTime>(nullable: false),
                    ClosedHours = table.Column<DateTime>(nullable: false),
                    StaffCount = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Shops", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Bricks",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Type = table.Column<string>(maxLength: 40, nullable: true),
                    X = table.Column<int>(nullable: false),
                    Y = table.Column<int>(nullable: false),
                    Z = table.Column<int>(nullable: false),
                    InventorId = table.Column<int>(nullable: false),
                    PricePerUnit = table.Column<decimal>(type: "decimal(4,2)", nullable: false),
                    DateOfCreation = table.Column<DateTime>(nullable: false),
                    ShopId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Bricks", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Bricks_Inventors_InventorId",
                        column: x => x.InventorId,
                        principalTable: "Inventors",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Bricks_Shops_ShopId",
                        column: x => x.ShopId,
                        principalTable: "Shops",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ShopBricks",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ShopId = table.Column<int>(nullable: false),
                    BrickId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ShopBricks", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ShopBricks_Bricks_BrickId",
                        column: x => x.BrickId,
                        principalTable: "Bricks",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ShopBricks_Shops_ShopId",
                        column: x => x.ShopId,
                        principalTable: "Shops",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Inventors",
                columns: new[] { "Id", "AtTheAgeOf", "DateCreated", "FName", "LName", "TimeOfCreation" },
                values: new object[] { 1, (byte)15, new DateTime(1522, 12, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), "Todi", "Boqnov", new DateTime(2356, 12, 12, 21, 12, 52, 0, DateTimeKind.Unspecified) });

            migrationBuilder.InsertData(
                table: "Shops",
                columns: new[] { "Id", "Capacity", "ClosedHours", "Location", "OpenHours", "ShopName", "StaffCount" },
                values: new object[] { 1, 526325215L, new DateTime(2356, 12, 12, 19, 0, 0, 0, DateTimeKind.Unspecified), "No:3 Kocatepe, Istanbul", new DateTime(2356, 12, 12, 8, 0, 0, 0, DateTimeKind.Unspecified), "LegoLand", 500 });

            migrationBuilder.InsertData(
                table: "Bricks",
                columns: new[] { "Id", "DateOfCreation", "InventorId", "PricePerUnit", "ShopId", "Type", "X", "Y", "Z" },
                values: new object[] { 1, new DateTime(1522, 12, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), 1, 0.02m, null, "Brick", 3, 2, 3 });

            migrationBuilder.InsertData(
                table: "ShopBricks",
                columns: new[] { "Id", "BrickId", "ShopId" },
                values: new object[] { 1, 1, 1 });

            migrationBuilder.CreateIndex(
                name: "IX_Bricks_InventorId",
                table: "Bricks",
                column: "InventorId");

            migrationBuilder.CreateIndex(
                name: "IX_Bricks_ShopId",
                table: "Bricks",
                column: "ShopId");

            migrationBuilder.CreateIndex(
                name: "IX_Bricks_Type",
                table: "Bricks",
                column: "Type",
                unique: true,
                filter: "[Type] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_ShopBricks_BrickId",
                table: "ShopBricks",
                column: "BrickId");

            migrationBuilder.CreateIndex(
                name: "IX_ShopBricks_ShopId",
                table: "ShopBricks",
                column: "ShopId");

            migrationBuilder.CreateIndex(
                name: "IX_Shops_Location",
                table: "Shops",
                column: "Location",
                unique: true,
                filter: "[Location] IS NOT NULL");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ShopBricks");

            migrationBuilder.DropTable(
                name: "Bricks");

            migrationBuilder.DropTable(
                name: "Inventors");

            migrationBuilder.DropTable(
                name: "Shops");
        }
    }
}
