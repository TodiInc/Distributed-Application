﻿using LegoLibrary.Queries;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using ModelLib.Models;

namespace LegoLibrary.RepoClasses
{
    class InventorClassRepo : I_InventorRepository
    {
        private LegoShopDBContext context;

        public InventorClassRepo(LegoShopDBContext context)
        {
            this.context = context;
        }

        public IEnumerable<Inventor> GetInventors()
        {
            return context.Inventors;
        }
        public Inventor GetInventorByID(int inventorId)
        {
            return context.Inventors.Find(inventorId);
        }

        public void InsertInventor(Inventor inventor)
        {
            context.Inventors.Add(inventor);
        }

        public void DeleteInventor(int inventorId)
        {
            Inventor inventor = context.Inventors.Find(inventorId);
            context.Inventors.Remove(inventor);
        }

        public void UpdateInventor(Inventor inventor)
        {
            context.Entry(inventor).State = EntityState.Modified;
        }

        public void Save()
        {
            context.SaveChanges();
        }
    }
}
