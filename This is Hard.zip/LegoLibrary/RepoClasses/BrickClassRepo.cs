﻿using LegoLibrary.Queries;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using ModelLib.Models;

namespace LegoLibrary.RepoClasses
{
    class BrickClassRepo : IBrickRepository
    {
        private LegoShopDBContext context;

        public BrickClassRepo(LegoShopDBContext context)
        {
            this.context = context;
        }

        public IEnumerable<Brick> GetBricks()
        {
            return context.Bricks;
        }
        public Brick GetBrickByID(int brickId)
        {
            return context.Bricks.Find(brickId);
        }

        public void InsertBrick(Brick brick)
        {
            context.Bricks.Add(brick);
        }

        public void DeleteBrick(int brickId)
        {
            Brick brick = context.Bricks.Find(brickId);
            context.Bricks.Remove(brick);
        }

        public void UpdateBrick(Brick brick)
        {
            context.Entry(brick).State = EntityState.Modified;
        }

        public void Save()
        {
            context.SaveChanges();
        }
    }
}
