﻿using LegoLibrary.Queries;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using ModelLib.Models;

namespace LegoLibrary.RepoClasses
{
    class ShopClassRepo : IShopRepository
    {
        private LegoShopDBContext context;

        public ShopClassRepo(LegoShopDBContext context)
        {
            this.context = context;
        }

        public IEnumerable<Shop> GetShops()
        {
            return context.Shops;
        }
        public Shop GetShopByID(int shopId)
        {
            return context.Shops.Find(shopId);
        }

        public void InsertShop(Shop shop)
        {
            context.Shops.Add(shop);
        }

        public void DeleteShop(int shopId)
        {
            Shop shop = context.Shops.Find(shopId);
            context.Shops.Remove(shop);
        }

        public void UpdateShop(Shop shop)
        {
            context.Entry(shop).State = EntityState.Modified;
        }

        public void Save()
        {
            context.SaveChanges();
        }
    }
}
